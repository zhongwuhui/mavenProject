package wk.entity;

/**
 * 审核表实体类
 * Created by Administrator on 2018/8/29.
 *
 */
public class shEntity {
    protected 	String	bsm	;
    protected	String	ywh	;
    protected	String	qlbm	;
    protected	String	qlbsm	;
    protected	String	lcdm	;
    protected	String	shlx	;
    protected	String	qllx	;
    protected	String	djlx	;
    protected	String	qlrmc	;
    protected	String	qlrtxdz	;
    protected	String	ywrdljg	;
    protected	String	bdcdyh	;
    protected	String	zl	;
    protected	String	slr	;
    protected	String	slsj	;
    protected	String	slyj	;
    protected	String	slrsgzh	;
    protected	String	slrbsm	;
    protected	String	csr	;
    protected	String	csrsgzh	;
    protected	String	csrbsm	;
    protected	String	csyj	;
    protected	String	cssj	;
    protected	String	fsr	;
    protected	String	fsrsgzh	;
    protected	String	fsrbsm	;
    protected	String	fsyj	;
    protected	String	fssj	;
    protected	String	hdr	;
    protected	String	hdrsgzh	;
    protected	String	hdrbsm	;
    protected	String	hdyj	;
    protected	String	hdsj	;
    protected	String	dbr	;
    protected	String	yxtbm	;
    protected	String	yxtbsm	;
    protected	String	qxdm	;
    protected	String	rev_	;
    protected	String	bz_yzdqlrid	;
    protected	String	bz_add1	;
    protected	String	bz_zdqlr_id	;
    protected	String	gxsj;
    protected  String islike;
    public String getIslike() {
        return islike;
    }

    public void setIslike(String islike) {
        this.islike = islike;
    }



    public String getBsm() {
        return bsm;
    }

    public void setBsm(String bsm) {
        this.bsm = bsm;
    }

    public String getYwh() {
        return ywh;
    }

    public void setYwh(String ywh) {
        this.ywh = ywh;
    }

    public String getQlbm() {
        return qlbm;
    }

    public void setQlbm(String qlbm) {
        this.qlbm = qlbm;
    }

    public String getQlbsm() {
        return qlbsm;
    }

    public void setQlbsm(String qlbsm) {
        this.qlbsm = qlbsm;
    }

    public String getLcdm() {
        return lcdm;
    }

    public void setLcdm(String lcdm) {
        this.lcdm = lcdm;
    }

    public String getShlx() {
        return shlx;
    }

    public void setShlx(String shlx) {
        this.shlx = shlx;
    }

    public String getQllx() {
        return qllx;
    }

    public void setQllx(String qllx) {
        this.qllx = qllx;
    }

    public String getDjlx() {
        return djlx;
    }

    public void setDjlx(String djlx) {
        this.djlx = djlx;
    }

    public String getQlrmc() {
        return qlrmc;
    }

    public void setQlrmc(String qlrmc) {
        this.qlrmc = qlrmc;
    }

    public String getQlrtxdz() {
        return qlrtxdz;
    }

    public void setQlrtxdz(String qlrtxdz) {
        this.qlrtxdz = qlrtxdz;
    }

    public String getYwrdljg() {
        return ywrdljg;
    }

    public void setYwrdljg(String ywrdljg) {
        this.ywrdljg = ywrdljg;
    }

    public String getBdcdyh() {
        return bdcdyh;
    }

    public void setBdcdyh(String bdcdyh) {
        this.bdcdyh = bdcdyh;
    }

    public String getZl() {
        return zl;
    }

    public void setZl(String zl) {
        this.zl = zl;
    }

    public String getSlr() {
        return slr;
    }

    public void setSlr(String slr) {
        this.slr = slr;
    }

    public String getSlsj() {
        return slsj;
    }

    public void setSlsj(String slsj) {
        this.slsj = slsj;
    }

    public String getSlyj() {
        return slyj;
    }

    public void setSlyj(String slyj) {
        this.slyj = slyj;
    }

    public String getSlrsgzh() {
        return slrsgzh;
    }

    public void setSlrsgzh(String slrsgzh) {
        this.slrsgzh = slrsgzh;
    }

    public String getSlrbsm() {
        return slrbsm;
    }

    public void setSlrbsm(String slrbsm) {
        this.slrbsm = slrbsm;
    }

    public String getCsr() {
        return csr;
    }

    public void setCsr(String csr) {
        this.csr = csr;
    }

    public String getCsrsgzh() {
        return csrsgzh;
    }

    public void setCsrsgzh(String csrsgzh) {
        this.csrsgzh = csrsgzh;
    }

    public String getCsrbsm() {
        return csrbsm;
    }

    public void setCsrbsm(String csrbsm) {
        this.csrbsm = csrbsm;
    }

    public String getCsyj() {
        return csyj;
    }

    public void setCsyj(String csyj) {
        this.csyj = csyj;
    }

    public String getCssj() {
        return cssj;
    }

    public void setCssj(String cssj) {
        this.cssj = cssj;
    }

    public String getFsr() {
        return fsr;
    }

    public void setFsr(String fsr) {
        this.fsr = fsr;
    }

    public String getFsrsgzh() {
        return fsrsgzh;
    }

    public void setFsrsgzh(String fsrsgzh) {
        this.fsrsgzh = fsrsgzh;
    }

    public String getFsrbsm() {
        return fsrbsm;
    }

    public void setFsrbsm(String fsrbsm) {
        this.fsrbsm = fsrbsm;
    }

    public String getFsyj() {
        return fsyj;
    }

    public void setFsyj(String fsyj) {
        this.fsyj = fsyj;
    }

    public String getFssj() {
        return fssj;
    }

    public void setFssj(String fssj) {
        this.fssj = fssj;
    }

    public String getHdr() {
        return hdr;
    }

    public void setHdr(String hdr) {
        this.hdr = hdr;
    }

    public String getHdrsgzh() {
        return hdrsgzh;
    }

    public void setHdrsgzh(String hdrsgzh) {
        this.hdrsgzh = hdrsgzh;
    }

    public String getHdrbsm() {
        return hdrbsm;
    }

    public void setHdrbsm(String hdrbsm) {
        this.hdrbsm = hdrbsm;
    }

    public String getHdyj() {
        return hdyj;
    }

    public void setHdyj(String hdyj) {
        this.hdyj = hdyj;
    }

    public String getHdsj() {
        return hdsj;
    }

    public void setHdsj(String hdsj) {
        this.hdsj = hdsj;
    }

    public String getDbr() {
        return dbr;
    }

    public void setDbr(String dbr) {
        this.dbr = dbr;
    }

    public String getYxtbm() {
        return yxtbm;
    }

    public void setYxtbm(String yxtbm) {
        this.yxtbm = yxtbm;
    }

    public String getYxtbsm() {
        return yxtbsm;
    }

    public void setYxtbsm(String yxtbsm) {
        this.yxtbsm = yxtbsm;
    }

    public String getQxdm() {
        return qxdm;
    }

    public void setQxdm(String qxdm) {
        this.qxdm = qxdm;
    }

    public String getRev_() {
        return rev_;
    }

    public void setRev_(String rev_) {
        this.rev_ = rev_;
    }

    public String getBz_yzdqlrid() {
        return bz_yzdqlrid;
    }

    public void setBz_yzdqlrid(String bz_yzdqlrid) {
        this.bz_yzdqlrid = bz_yzdqlrid;
    }

    public String getBz_add1() {
        return bz_add1;
    }

    public void setBz_add1(String bz_add1) {
        this.bz_add1 = bz_add1;
    }

    public String getBz_zdqlr_id() {
        return bz_zdqlr_id;
    }

    public void setBz_zdqlr_id(String bz_zdqlr_id) {
        this.bz_zdqlr_id = bz_zdqlr_id;
    }

    public String getGxsj() {
        return gxsj;
    }

    public void setGxsj(String gxsj) {
        this.gxsj = gxsj;
    }

    ;

}
